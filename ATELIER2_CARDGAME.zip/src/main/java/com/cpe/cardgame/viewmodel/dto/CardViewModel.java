package com.cpe.cardgame.viewmodel.dto;

public class CardViewModel {
}